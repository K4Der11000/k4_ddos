
from flask import Flask, render_template, request, jsonify, send_file
import threading, requests, time, random, os, psutil, json
import cloudscraper

app = Flask(__name__)
lock = threading.Lock()
request_count = 0
is_running = False
proxies_list = []

# تحميل البروكسيات من الإنترنت
def fetch_proxies():
    global proxies_list
    url = "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt"
    try:
        response = requests.get(url)
        if response.status_code == 200:
            proxies_list = response.text.strip().split("\n")
    except:
        proxies_list = []

# إرسال الطلبات
def send_requests(urls):
    global request_count, is_running
    scraper = cloudscraper.create_scraper()
    while is_running:
        for url in urls:
            if not is_running:
                break
            try:
                proxy = {"http": random.choice(proxies_list), "https": random.choice(proxies_list)} if proxies_list else None
                res = scraper.get(url, proxies=proxy, timeout=5)
                with lock:
                    request_count += 1
            except:
                continue

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/start', methods=['POST'])
def start():
    global is_running, request_count
    data = request.json
    urls = data.get("urls", [])
    if not urls:
        return jsonify({"error": "No URLs"}), 400

    request_count = 0
    is_running = True
    threading.Thread(target=send_requests, args=(urls,), daemon=True).start()
    return jsonify({"status": "started"})

@app.route('/stop', methods=['POST'])
def stop():
    global is_running
    is_running = False
    return jsonify({"status": "stopped"})

@app.route('/status')
def status():
    cpu = psutil.cpu_percent()
    memory = psutil.virtual_memory().percent
    return jsonify({
        "count": request_count,
        "cpu": cpu,
        "memory": memory
    })

@app.route('/save')
def save():
    global request_count
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    with open("results.txt", "a") as f:
        f.write(f"[{timestamp}] Requests Sent: {request_count}\n")

    data = []
    if os.path.exists("history.json"):
        with open("history.json", "r") as h:
            try:
                data = json.load(h)
            except:
                data = []

    data.append({"time": timestamp, "count": request_count})
    with open("history.json", "w") as h:
        json.dump(data, h)

    table_rows = ''.join([f"<tr><td>{entry['time']}</td><td>{entry['count']}</td></tr>" for entry in data])
    labels = ', '.join([f"'{entry['time']}'" for entry in data])
    values = ', '.join([str(entry['count']) for entry in data])

    with open("results.html", "w") as f:
        f.write(f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Results - kader11000</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {{
            background: #000;
            color: #0f0;
            font-family: monospace;
            padding: 20px;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }}
        th, td {{
            border: 1px solid #0f0;
            padding: 10px;
            text-align: left;
        }}
        h2 {{
            text-shadow: 0 0 5px #0f0;
        }}
        canvas {{
            background: #111;
            border: 1px solid #0f0;
            padding: 10px;
            margin-top: 20px;
        }}
    </style>
</head>
<body>
    <h2>kader11000 | Web Requests History</h2>
    <table>
        <tr><th>Time</th><th>Requests Sent</th></tr>
        {table_rows}
    </table>
    <canvas id="chart" width="400" height="200"></canvas>
    <script>
        const ctx = document.getElementById('chart').getContext('2d');
        const chart = new Chart(ctx, {{
            type: 'line',
            data: {{
                labels: [{labels}],
                datasets: [{{
                    label: 'Requests Sent',
                    data: [{values}],
                    backgroundColor: 'rgba(0,255,0,0.2)',
                    borderColor: 'lime',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.3
                }}]
            }},
            options: {{
                scales: {{
                    y: {{
                        beginAtZero: true
                    }}
                }},
                plugins: {{
                    legend: {{
                        labels: {{
                            color: 'lime'
                        }}
                    }}
                }}
            }}
        }});
    </script>
</body>
</html>
""")

    return jsonify({"status": "saved"})

@app.route('/read')
def read_file():
    if not os.path.exists("results.txt"):
        return "لا توجد نتائج حالياً"
    with open("results.txt", "r") as f:
        return f.read()

@app.route('/download')
def download_file():
    return send_file("results.txt", as_attachment=True)

@app.route('/download_html')
def download_html():
    return send_file("results.html", as_attachment=True)

@app.route('/delete', methods=['POST'])
def delete_file():
    try:
        os.remove("results.txt")
        return jsonify({"message": "تم حذف الملف بنجاح"})
    except:
        return jsonify({"message": "حدث خطأ أثناء الحذف"})

if __name__ == '__main__':
    fetch_proxies()
    app.run(debug=True)
